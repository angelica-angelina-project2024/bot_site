zodiac_signs = {
    "Aries": "♈️ Овен ♈",
    "Taurus": "♉️ Телец ♉️",
    "Gemini": "♊️ Близнецы ♊",
    "Cancer": "♋️ Рак ♋",
    "Leo": "♌️ Лев ♌",
    "Virgo": "♍️ Дева ♍",
    "Libra": "♎️ Весы ♎",
    "Scorpio": "♏️ Скорпион ♏",
    "Sagittarius": "♐️ Стрелец ♐",
    "Capricorn": "♑️ Козерог ♑",
    "Aquarius": "♒️ Водолей ♒",
    "Pisces": "♓️ Рыбы ♓"
}

zodiac_list = ['aries', 'taurus', 'gemini', 'cancer', 'leo', 'virgo', 'libra','scorpio', 'sagittarius', 'capricorn',
               'aquarius', 'pisces']