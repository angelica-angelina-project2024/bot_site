import json
import sqlite3
import telebot
import requests

from bs4 import BeautifulSoup
from telebot import types
from py_files_dicts.films import films_genre_list
from py_files_dicts.music import music_genre_list
from py_files_dicts.names import zodiac_signs, zodiac_list


bot = telebot.TeleBot('6608758977:AAGUJ5_IoxQoBugAtjv8K0ii98svEiDqack')
API = 'd507e7334b3ee346eb3a6445930f347b'
name = None


@bot.message_handler(commands=['site', 'website'])
def site(message):
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton('Перейти на сайт',
                                          url='https://39bd5cce-9f5d-4b55-9585-9101a7da1af9.tunnel4.com/index'))
    bot.reply_to(message, 'Сайт для более удобной работы', reply_markup=markup)


@bot.message_handler(commands=['start'])
def start(message):
    markup = types.ReplyKeyboardMarkup()
    conn = sqlite3.connect("static/databases/chatbot_db.sqlite")
    cur = conn.cursor()

    cur.execute('CREATE TABLE IF NOT EXISTS users (id int auto_increment primary key, name varchar(50), '
                'pass varchar(50))')
    conn.commit()
    cur.close()
    conn.close()

    file = open('static/images/logo.png', 'rb')

    bot.send_photo(message.chat.id, file, reply_markup=markup)
    bot.send_message(message.chat.id, f'Привет, сейчас тебя зарегистрируем! Введите ваше имя', reply_markup=markup)
    bot.register_next_step_handler(message, user_name)


def user_name(message):
    global name
    name = message.text.strip()
    bot.send_message(message.chat.id, "Введите пароль для регистрации")
    bot.register_next_step_handler(message, user_pass)


def user_pass(message):
    global name
    password = message.text.strip()
    greet = open('static/text/intro.txt')
    conn = sqlite3.connect("static/databases/chatbot_db.sqlite")
    cur = conn.cursor()

    cur.execute(f'INSERT INTO users (name, pass) VALUES ("%s", "%s")' % (name, password))
    conn.commit()
    cur.close()
    conn.close()

    markup = types.InlineKeyboardMarkup()
    bot.send_message(message.chat.id, f"Пользователь зарегистрирован!", reply_markup=markup)
    bot.send_message(message.chat.id, f"Привет, {name}! \n{greet.read()}", reply_markup=markup)


@bot.message_handler(commands=['weather', 'погода'])
def get_city(message):
    bot.reply_to(message, 'Введите город, в котором хотите узнать погоду ⛅')
    bot.register_next_step_handler(message, get_weather)


def get_weather(message):
    city = message.text.strip().lower()
    try:
        result = requests.get(f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API}&units=metric')
        data = json.loads(result.text)
        location = [data["coord"]["lon"], data["coord"]["lat"]]
        zoom = 10
        map_params = {
            'll': ','.join(map(str, location)),
            'l': 'map',
            'z': zoom}
        session = requests.Session()
        response = session.get('https://static-maps.yandex.ru/1.x/', params=map_params)
        with open('static/map/picture.png', mode='wb') as picture:
            picture.write(response.content)
        file = open('static/map/picture.png', 'rb')
        bot.send_photo(message.chat.id, file)
        bot.reply_to(message, f'Температура: {data["main"]["temp"]} ℃\n'
                              f'Ощущается: {data["main"]["feels_like"]} ℃\n'
                              f'Давление: {round(int(data["main"]["pressure"]) * 0.750064)} мм. рт. ст.\n'
                              f'Влажность: {data["main"]["humidity"]}%\n'
                              f'Ветер: {data["wind"]["speed"]} м/с\n')
    except KeyError:
        bot.reply_to(message, 'Проверьте, правильно ли введён город. Запустите команду /weather или /погода'
                              ' ещё раз и введите город.')


@bot.message_handler(commands=['horoscope', 'гороскоп'])
def get_horoscope(message):
    markup = types.InlineKeyboardMarkup()
    btn_aries = types.InlineKeyboardButton(text='♈️ Овен ♈️', callback_data='aries')
    markup.add(btn_aries)
    btn_taurus = types.InlineKeyboardButton(text='♉️ Телец ♉️', callback_data='taurus')
    markup.add(btn_taurus)
    btn_gemini = types.InlineKeyboardButton(text='♊️ Близнецы ♊️', callback_data='gemini')
    markup.add(btn_gemini)
    btn_cancer = types.InlineKeyboardButton(text='♋️ Рак ♋️', callback_data='cancer')
    markup.add(btn_cancer)
    btn_leo = types.InlineKeyboardButton(text='♌️ Лев ♌️', callback_data='leo')
    markup.add(btn_leo)
    btn_virgo = types.InlineKeyboardButton(text='♍️ Дева ♍️', callback_data='virgo')
    markup.add(btn_virgo)
    btn_libra = types.InlineKeyboardButton(text='♎️ Весы ♎️', callback_data='libra')
    markup.add(btn_libra)
    btn_scorpio = types.InlineKeyboardButton(text='♏️ Скорпион ♏️', callback_data='scorpio')
    markup.add(btn_scorpio)
    btn_sagittarius = types.InlineKeyboardButton(text='♐️ Стрелец ♐️', callback_data='sagittarius')
    markup.add(btn_sagittarius)
    btn_capricorn = types.InlineKeyboardButton(text='♑️ Козерог ♑️', callback_data='capricorn')
    markup.add(btn_capricorn)
    btn_aquarius = types.InlineKeyboardButton(text='♒️ Водолей ♒️', callback_data='aquarius')
    markup.add(btn_aquarius)
    btn_pisces = types.InlineKeyboardButton(text='♓️ Рыбы ♓️', callback_data='pisces')
    markup.add(btn_pisces)
    bot.send_message(message.from_user.id, text=f'{name}, выберите свой знак зодиака',
                     reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data in zodiac_list)
def return_horoscope(call):
    zodiac = call.data
    name = zodiac_signs[zodiac.capitalize()]
    url = f'https://horo.mail.ru/prediction/{zodiac}/today/'
    page = requests.get(url)
    soup = BeautifulSoup(page.text, "html.parser")
    horoscope = soup.find(name='div', class_='article__item article__item_alignment_left article__item_html').text
    bot.send_message(call.message.chat.id, f'{name}:\n{horoscope}')


@bot.message_handler(commands=['music', 'музыка'])
def choice_genre_music(message):
    markup = types.InlineKeyboardMarkup()
    btn_1 = types.InlineKeyboardButton(text='рок', callback_data='Rock')
    btn_2 = types.InlineKeyboardButton(text='джаз', callback_data='Jazz')
    btn_3 = types.InlineKeyboardButton(text='метал', callback_data='Metal')
    btn_4 = types.InlineKeyboardButton(text='альтернатива&панк', callback_data='Alternative & Punk')
    btn_5 = types.InlineKeyboardButton(text='рок-н-ролл', callback_data='Rock And Roll')
    btn_6 = types.InlineKeyboardButton(text='блюз', callback_data='Blues')
    btn_7 = types.InlineKeyboardButton(text='латиноамериканская музыка', callback_data='Latin')
    btn_8 = types.InlineKeyboardButton(text='регги', callback_data='Reggae')
    btn_9 = types.InlineKeyboardButton(text='поп-музыка', callback_data='Pop')
    btn_10 = types.InlineKeyboardButton(text='саундтрек', callback_data='Soundtrack')
    btn_11 = types.InlineKeyboardButton(text='босанова', callback_data='Bossa Nova')
    btn_12 = types.InlineKeyboardButton(text='легкая музыка', callback_data='Easy Listening')
    btn_13 = types.InlineKeyboardButton(text='хеви-метал', callback_data='Heavy Metal')
    btn_14 = types.InlineKeyboardButton(text='ритм-н-блюз', callback_data='R&B/Soul')
    btn_15 = types.InlineKeyboardButton(text='электроника', callback_data='Electronica/Dance')
    btn_16 = types.InlineKeyboardButton(text='мировая музыка', callback_data='World')
    btn_17 = types.InlineKeyboardButton(text='хип-хоп/рэп', callback_data='Hip Hop/Rap')
    btn_18 = types.InlineKeyboardButton(text='научная фантастика', callback_data='Science Fiction')
    btn_19 = types.InlineKeyboardButton(text='телешоу', callback_data='TV Shows')
    btn_20 = types.InlineKeyboardButton(text='научно-фантастические и фэнтези фильмы',
                                        callback_data='Sci Fi & Fantasy')
    btn_21 = types.InlineKeyboardButton(text='драма', callback_data='Drama')
    btn_22 = types.InlineKeyboardButton(text='комедия', callback_data='Comedy')
    btn_23 = types.InlineKeyboardButton(text='альтернатива', callback_data='Alternative ')
    btn_24 = types.InlineKeyboardButton(text='классическая', callback_data='Classical')
    btn_25 = types.InlineKeyboardButton(text='опера', callback_data='Opera')
    markup.add(btn_1, btn_2, btn_3, btn_4, btn_5, btn_6, btn_7, btn_8, btn_9, btn_10, btn_11, btn_12, btn_13, btn_14,
               btn_15, btn_16, btn_17, btn_18, btn_19, btn_20, btn_21, btn_22, btn_23, btn_24, btn_25)
    bot.send_message(message.from_user.id, text=f"Выберите жанр музыки", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data in music_genre_list)
def return_music(call):
    genre = call.data
    con = sqlite3.connect('static/databases/Chinook_Sqlite.sqlite')
    cur = con.cursor()
    query = cur.execute(f"""SELECT Name FROM Track WHERE GenreId in (SELECT GenreId FROM Genre
              WHERE Name IN (?))""", (genre,)).fetchall()
    result = []
    for record in query:
        result.append(*record)
    answer = f'{genre}:\n'
    for record in result:
        answer += f'✩{record}\n'
    if len(answer) > 4096:
        for symbol in range(0, len(answer), 4096):
            bot.send_message(call.message.chat.id, answer[symbol:symbol + 4096])
    else:
        bot.send_message(call.message.chat.id, answer)


@bot.message_handler(commands=['films', 'фильм', 'фильмы'])
def choice_genre_films(message):
    global name
    markup = types.InlineKeyboardMarkup(row_width=2)
    btn_1 = types.InlineKeyboardButton(text='комедия', callback_data='комедия')
    btn_2 = types.InlineKeyboardButton(text='драма', callback_data='драма')
    btn_3 = types.InlineKeyboardButton(text='мелодрама', callback_data='мелодрама')
    btn_4 = types.InlineKeyboardButton(text='детектив', callback_data='детектив')
    btn_5 = types.InlineKeyboardButton(text='документальный', callback_data='документальный')
    btn_6 = types.InlineKeyboardButton(text='ужасы', callback_data='ужасы')
    btn_7 = types.InlineKeyboardButton(text='музыка', callback_data='фантастика')
    btn_8 = types.InlineKeyboardButton(text='фантастика', callback_data='фантастика')
    btn_9 = types.InlineKeyboardButton(text='анимация', callback_data='анимация')
    btn_10 = types.InlineKeyboardButton(text='биография', callback_data='биография')
    btn_11 = types.InlineKeyboardButton(text='боевик', callback_data='боевик')
    btn_12 = types.InlineKeyboardButton(text='приключения', callback_data='боевик')
    btn_13 = types.InlineKeyboardButton(text='война', callback_data='война')
    btn_14 = types.InlineKeyboardButton(text='семейный', callback_data='семейный')
    btn_15 = types.InlineKeyboardButton(text='триллер', callback_data='триллер')
    btn_16 = types.InlineKeyboardButton(text='фэнтези', callback_data='фэнтези')
    btn_17 = types.InlineKeyboardButton(text='вестерн', callback_data='вестерн')
    btn_18 = types.InlineKeyboardButton(text='мистика', callback_data='мистика')
    btn_19 = types.InlineKeyboardButton(text='короткометражный', callback_data='короткометражный')
    btn_20 = types.InlineKeyboardButton(text='мюзикл', callback_data='мюзикл ')
    btn_21 = types.InlineKeyboardButton(text='исторический', callback_data='исторический')
    btn_22 = types.InlineKeyboardButton(text='нуар', callback_data='нуар')
    markup.add(btn_1, btn_2, btn_3, btn_4, btn_5, btn_6, btn_7, btn_8, btn_9, btn_10, btn_11, btn_12, btn_13, btn_14,
               btn_15, btn_16, btn_17, btn_18, btn_19, btn_20, btn_21, btn_22)
    bot.send_message(message.from_user.id, text=f'{name}, выберите жанр фильма', reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data in films_genre_list)
def return_films(call):
    genre = call.data
    con = sqlite3.connect('static/databases/films_db.sqlite')
    cur = con.cursor()
    query = cur.execute(f"""SELECT title FROM films WHERE genre in (SELECT id FROM genres
            WHERE title IN ('{genre}'))""").fetchall()
    result = []
    for record in query:
        result.append(*record)
    answer = f'{genre}:\n'
    for record in result:
        answer += f'✩{record}\n'
    if len(answer) > 4096:
        for symbol in range(0, len(answer), 4096):
            bot.send_message(call.message.chat.id, answer[symbol:symbol + 4096])
    else:
        bot.send_message(call.message.chat.id, answer)


@bot.message_handler(commands=['news', 'новости'])
def get_news(message):
    result = ''
    news_site = f'https://ria.ru/search/'
    page = requests.get(news_site)
    soup = BeautifulSoup(page.text, "html.parser")
    news_list = soup.find_all("a", {"class": "list-item__title"})
    for news in news_list:
        result += f'\n❗<a href="{news.get("href")}">{news.text}\n</a>'
    bot.send_message(message.chat.id, result, parse_mode='html')


bot.polling(none_stop=True)

