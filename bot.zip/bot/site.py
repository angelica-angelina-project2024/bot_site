import json
import os
import sqlite3
import requests

from flask import Flask, url_for, request
from bs4 import BeautifulSoup
from py_files_dicts.names import zodiac_signs

app = Flask(__name__)
API = 'd507e7334b3ee346eb3a6445930f347b'


zodiac_signs_en = {
    "Овен": "Aries",
    "Телец": "Taurus",
    "Близнецы": "Gemini",
    "Рак": "Cancer",
    "Лев": "Leo",
    "Дева": "Virgo",
    "Весы": "Libra",
    "Скорпион": "Scorpio",
    "Стрелец": "Sagittarius",
    "Козерог": "Capricorn",
    "Водолей": "Aquarius",
    "Рыбы": "Pisces"
}

musics_en = {
    "Рок": "Rock",
    "Джаз": "Jazz",
    "Метал": "Metal",
    "Альтернатива": "Alternative",
    "Панк": "Punk",
    "Рок-н-ролл": "Rock And Roll",
    "Блюз": "Blues",
    "Латиноамериканская": "Latin",
    "Регги": "Reggae",
    "Поп-музыка": "Pop",
    "Саундтрек": "Soundtrack",
    "Басанова": "Bossa Nova",
    "Легкая музыка": "Easy Listening",
    "Хеви-метал": "Heavy Metal",
    "Ритм-н-блюз": "R&B/Soul",
    "Электроника": "Electronica/Dance",
    "Мировая музыка": "World",
    "Рэп": "Rap",
    "Хип-хоп": "Hip Hop",
    "Классическая": "Classical",
    "Опера": "Opera"
}


@app.route('/index')
def site():
    return f"""<!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Работа с API</title>
                    <link rel="stylesheet" href="{url_for('static', filename='styles/style.css')}" />
                    <link
                      rel="icon"
                      type="image/x-icon"
                      sizes="any"
                      href="{url_for('static', filename='images/logo.png')}"
                    />
                </head>
                <body>
                    <header class="header">
                        <section class="header-section">
                            <button class="header-section_button"><a href="#weather">Погода</a></button>
                            <button class="header-section_button"><a href="#zodiac_sign">Гороскоп</a></button>
                        </section>
                        <section class="header-section">
                            <button class="header-section_button"><a href="#films">Фильмы</a></button>
                            <button class="header-section_button"><a href="#music">Музыка</a></button>
                        </section>
                    </header>
                
                    <main class="main">
                        <section id="zodiac_sign">
                            <h1 class="title">Гороскоп</h1>
                
                            <div class="input-div">
                                <h2 class="input-title">Введите знак зодиака:</h2>
                                <form action="/zodiac_sign" method="post">
                                    <input class="input" type="text" placeholder="Знак зодиака" name="input_zodiac">
                                    <button class="btn">
                                        <svg width="180px" height="60px" viewBox="0 0 180 60" class="border">
                                          <polyline points="179,1 179,59 1,59 1,1 179,1" class="bg-line" />
                                          <polyline points="179,1 179,59 1,59 1,1 179,1" class="hl-line" />
                                        </svg>
                                        <span>Сгенерировать</span>
                                    </button>
                                </form>
                            </div>
                        </section>
                
                        <section id="films">
                            <h1 class="title">Фильмы</h1>
                
                            <div class="input-div">
                                <h2 class="input-title">Введите жанр фильма:</h2>
                                <form action="/films" method="post">
                                    <input class="input" type="text" placeholder="Название жанра фильма" 
                                    name="input_film">
                                    <button class="btn">
                                        <svg width="180px" height="60px" viewBox="0 0 180 60" class="border">
                                          <polyline points="179,1 179,59 1,59 1,1 179,1" class="bg-line" />
                                          <polyline points="179,1 179,59 1,59 1,1 179,1" class="hl-line" />
                                        </svg>
                                        <span>Сгенерировать</span>
                                    </button>
                                </form>
                            </div>
                        </section>
                
                        <section id="music">
                            <h1 class="title">Музыка</h1>
                
                            <div class="input-div">
                                <h2 class="input-title">Введите жанр музыки:</h2>
                                <form action="/musics" method="post">
                                    <input class="input" type="text" placeholder="Название жанра музыки" name="input_music">
                                    <button class="btn">
                                        <svg width="180px" height="60px" viewBox="0 0 180 60" class="border">
                                          <polyline points="179,1 179,59 1,59 1,1 179,1" class="bg-line" />
                                          <polyline points="179,1 179,59 1,59 1,1 179,1" class="hl-line" />
                                        </svg>
                                        <span>Сгенерировать</span>
                                    </button>
                                </form>    
                            </div>
                        </section>
                        
                        <section id="weather">
                            <h1 class="title">Погода</h1>
                
                            <div class="input-div">
                                <h2 class="input-title">Введите местоположение, где хотите узнать погоду:</h2>
                                <form action="/weather" method="post">
                                    <input class="input" type="text" placeholder="Название города" name="input_weather">
                                    <button class="btn">
                                        <svg width="180px" height="60px" viewBox="0 0 180 60" class="border">
                                          <polyline points="179,1 179,59 1,59 1,1 179,1" class="bg-line" />
                                          <polyline points="179,1 179,59 1,59 1,1 179,1" class="hl-line" />
                                        </svg>
                                        <span>Сгенерировать</span>
                                    </button>
                                </form>
                            </div>
                        </section>
                    </main>
                
                    <footer class="footer">
                        <p class="footer-text">Посетите нашего бота</p>
                
                        <a class="footer_social-link" href="https://t.me/seacherinfo_bot" target="_blank">
                            <img
                                class="footer_social-icon" 
                                src="{url_for('static', filename='images/tg.png')}" 
                                alt="Логотип Telegram"/>
                        </a>
                    </footer>
                </body>
                </html>"""


@app.route('/weather', methods=['POST'])
def weather_city():
    name_city = ''
    if request.method == 'POST':
        name_city = request.form['input_city']

    try:
        city = name_city.strip().lower()

        result = requests.get(f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid={API}&units=metric')
        data = result.json()
        return (city, f'Температура: {data["main"]["temp"]} ℃\n'
                      f'Ощущается: {data["main"]["feels_like"]} ℃\n'
                      f'Давление: {round(int(data["main"]["pressure"]) * 0.750064)} мм. рт. ст.\n'
                      f'Влажность: {data["main"]["humidity"]}%\n'
                      f'Ветер: {data["wind"]["speed"]} м/с\n')

    except Exception:
        return 'Ошибка. Возможно вы ввели неправильный запрос. Попробуйте снова'


@app.route('/zodiac_sign', methods=['POST'])
def zodiac_sign():
    zodiac = ''
    if request.method == 'POST':
        zodiac = request.form['input_zodiac']

    try:
        zodiac = zodiac_signs_en[zodiac.capitalize()]

        beautiful_zodiac_signs = zodiac_signs[zodiac.capitalize()]
        url = f'https://horo.mail.ru/prediction/{zodiac.lower()}/today/'
        page = requests.get(url)
        soup = BeautifulSoup(page.text, "html.parser")
        horoscope = soup.find(name='div', class_='article__item article__item_alignment_left article__item_html').text

        return f"""<!DOCTYPE html>
                        <html lang="en">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            <title>Работа с API</title>
                            <link rel="stylesheet" href="{url_for('static', 
                                                                  filename='styles/style_second.css')}" />
                            <link
                              rel="icon"
                              type="image/x-icon"
                              sizes="any"
                              href="{url_for('static', filename='images/logo.png')}"
                            />
                        </head>
                        <body>
                            <h1>{beautiful_zodiac_signs}</h1>
                            <p>{horoscope}</p>
                        </body>
                        </html>"""

    except Exception:
        return 'Ошибка. Возможно вы ввели неправильный запрос. Попробуйте снова'


@app.route('/films', methods=['POST'])
def films():
    genre_film = ''
    if request.method == 'POST':
        genre_film = request.form['input_film']

    try:
        con = sqlite3.connect('static/databases/films_db.sqlite')
        cur = con.cursor()
        query = cur.execute(f"""SELECT title FROM films WHERE genre in (SELECT id FROM genres
                    WHERE title IN ('{genre_film.lower()}'))""").fetchall()
        result = []
        for i in query:
            result.append(*i)
        answer = ''
        for i in result:
            answer += f'✩{i}\n'
        if len(answer) > 4096:
            for x in range(0, len(answer), 4096):
                return f"""<!DOCTYPE html>
                        <html lang="en">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            <title>Работа с API</title>
                            <link rel="stylesheet" href="{url_for('static', 
                                                                  filename='styles/style_second.css')}" />
                            <link
                              rel="icon"
                              type="image/x-icon"
                              sizes="any"
                              href="{url_for('static', filename='images/logo.png')}"
                            />
                        </head>
                        <body>
                            <h1>{genre_film.capitalize()}</h1>
                            <p>{answer[x:x + 4096]}...</p>
                        </body>
                        </html>"""
        else:
            return f"""<!DOCTYPE html>
                        <html lang="en">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            <title>Работа с API</title>
                            <link rel="stylesheet" href="./styles/style_second.css" />
                            <link
                              rel="icon"
                              type="image/x-icon"
                              sizes="any"
                              href="./images/logo.png"
                            />
                        </head>
                        <body>
                            <h1>{genre_film.capitalize()}</h1>
                            <p>{answer}</p>
                        </body>
                        </html>"""

    except Exception:
        return 'Ошибка. Возможно вы ввели неправильный запрос. Попробуйте снова'


@app.route('/musics', methods=['POST'])
def musics():
    music = ''
    if request.method == 'POST':
        music = request.form['input_music']

    try:
        genre_music = musics_en[music.capitalize()]

        con = sqlite3.connect('static/databases/Chinook_Sqlite.sqlite')
        cur = con.cursor()
        query = cur.execute(f"""SELECT Name FROM Track WHERE GenreId in (SELECT GenreId FROM Genre
                      WHERE Name IN (?))""", (genre_music,)).fetchall()
        result = []
        for i in query:
            result.append(*i)
        answer = ''
        for i in result:
            answer += f'✩{i}\n'
        if len(answer) > 4096:
            for x in range(0, len(answer), 4096):
                return f"""<!DOCTYPE html>
                        <html lang="en">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            <title>Работа с API</title>
                            <link rel="stylesheet" href="{url_for('static', 
                                                                  filename='styles/style_second.css')}" />
                            <link
                              rel="icon"
                              type="image/x-icon"
                              sizes="any"
                              href="{url_for('static', filename='images/logo.png')}"
                            />
                        </head>
                        <body>
                            <h1>{genre_music}</h1>
                            <p>{answer[x:x + 4096]}</p>
                        </body>
                        </html>"""
        else:
            return f"""<!DOCTYPE html>
                        <html lang="en">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            <title>Работа с API</title>
                            <link rel="stylesheet" href="{url_for('static', 
                                                                  filename='styles/style_second.css')}" />
                            <link
                              rel="icon"
                              type="image/x-icon"
                              sizes="any"
                              href="{url_for('static', filename='images/logo.png')}"
                            />
                        </head>
                        <body>
                            <h1>{genre_music}</h1>
                            <p>{answer}</p>
                        </body>
                        </html>"""

    except Exception:
        return 'Ошибка. Возможно вы ввели неправильный запрос. Попробуйте снова'


if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5000))
    app.run(host='0.0.0.0', port=port)